Drupal.locale = { 'strings': {"":{"An AJAX HTTP error occurred.":"C\u00f3 l\u1ed7i AJAX HTTP.","HTTP Result Code: !status":"K\u1ebft qu\u1ea3 m\u00e3 HTTP: !status","An AJAX HTTP request terminated abnormally.":"Y\u00eau c\u1ea7u AJAX HTTP k\u1ebft th\u00fac b\u1ea5t th\u01b0\u1eddng.","Debugging information follows.":"R\u00e0 l\u1ed7i theo th\u00f4ng tin sau.","Path: !uri":"\u0110\u01b0\u1eddng d\u1eabn: !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseTextt: !responseText","ReadyState: !readyState":"ReadyState: !readyState","All":"T\u1ea5t c\u1ea3","Re-order rows by numerical weight instead of dragging.":"S\u1eafp x\u1ebfp l\u1ea1i danh m\u1ee5c theo \u0111\u1ed9 n\u1eb7ng thay v\u00ec k\u00e9o ch\u00fang.","Show row weights":"Hi\u1ec7n tr\u1ecdng s\u1ed1 h\u00e0ng","Hide row weights":"\u1ea8n tr\u1ecdng s\u1ed1 h\u00e0ng","Drag to re-order":"K\u00e9o \u0111\u1ec3 s\u1eafp x\u1ebfp l\u1ea1i","Changes made in this table will not be saved until the form is submitted.":"C\u00e1c thay \u0111\u1ed5i \u0111\u01b0\u1ee3c th\u1ef1c hi\u1ec7n trong b\u1ea3ng n\u00e0y s\u1ebd kh\u00f4ng \u0111\u01b0\u1ee3c l\u01b0u cho \u0111\u1ebfn khi bi\u1ec3u m\u1eabu \u0111\u01b0\u1ee3c \u0111\u1ec7 tr\u00ecnh.","Hide":"\u1ea8n","Show":"Hi\u1ec7n","Disabled":"T\u1eaft","Edit":"S\u1eeda","Add":"Th\u00eam","Upload":"T\u1ea3i l\u00ean","Configure":"C\u1ea5u h\u00ecnh","Done":"Xong","This field is required.":"Tr\u01b0\u1eddng d\u1eef li\u1ec7u n\u00e0y l\u00e0 b\u1eaft bu\u1ed9c.","Select all rows in this table":"Ch\u1ecdn t\u1ea5t c\u1ea3 c\u00e1c d\u00f2ng trong b\u1ea3ng n\u00e0y","Deselect all rows in this table":"B\u1ecf ch\u1ecdn t\u1ea5t c\u1ea3 c\u00e1c d\u00f2ng trong b\u1ea3ng n\u00e0y","Not published":"Ch\u01b0a c\u00f4ng b\u1ed1","Please wait...":"Vui l\u00f2ng \u0111\u1ee3i...","Only files with the following extensions are allowed: %files-allowed.":"Ch\u1ec9 nh\u1eefng t\u1eadp tin c\u00f3 ph\u1ea7n m\u1edf r\u1ed9ng sau m\u1edbi \u0111\u01b0\u1ee3c ph\u00e9p: %files-allowed.","By @name on @date":"B\u1edfi @name v\u00e0o l\u00fac @date","By @name":"@name vi\u1ebft","Not in menu":"Kh\u00f4ng c\u00f3 trong tr\u00ecnh \u0111\u01a1n","Alias: @alias":"\u0110\u01b0\u1eddng d\u1eabn \u1ea3o: @alias","No alias":"Ch\u01b0a c\u00f3 \u0111\u01b0\u1eddng d\u1eabn \u1ea3o","New revision":"Phi\u00ean b\u1ea3n m\u1edbi","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"C\u00e1c thay \u0111\u1ed5i \u0111\u1ed1i v\u1edbi c\u00e1c kh\u1ed1i n\u1ed9i dung n\u00e0y s\u1ebd ch\u01b0a \u0111\u01b0\u1ee3c l\u01b0u cho \u0111\u1ebfn khi n\u00fat \u003Cem\u003EL\u01b0u c\u00e1c kh\u1ed1i n\u1ed9i dung\u003C\/em\u003E \u0111\u01b0\u1ee3c nh\u1ea5p.","This permission is inherited from the authenticated user role.":"Quy\u1ec1n n\u00e0y \u0111\u01b0\u1ee3c k\u1ebf th\u1eeba t\u1eeb vai tr\u00f2 ng\u01b0\u1eddi d\u00f9ng \u0111\u00e3 x\u00e1c th\u1ef1c.","No revision":"Kh\u00f4ng c\u00f3 phi\u00ean b\u1ea3n n\u00e0o","@number comments per page":"@number l\u1eddi b\u00ecnh m\u1ed7i trang","Requires a title":"Ph\u1ea7n ti\u00eau \u0111\u1ec1 l\u00e0 b\u1eaft bu\u1ed9c","Not restricted":"Kh\u00f4ng h\u1ea1n ch\u1ebf","(active tab)":"(tab ho\u1ea1t \u0111\u1ed9ng)","Not customizable":"Ng\u01b0\u1eddi d\u00f9ng kh\u00f4ng \u0111\u01b0\u1ee3c ph\u00e9p t\u00f9y ch\u1ec9nh","Restricted to certain pages":"H\u1ea1n ch\u1ebf \u0111\u1ed1i v\u1edbi m\u1ed9t s\u1ed1 trang","The block cannot be placed in this region.":"Kh\u00f4ng th\u1ec3 \u0111\u01b0a kh\u1ed1i n\u00e0y v\u00e0o v\u00f9ng n\u00e0y.","Customize dashboard":"S\u1eeda c\u1ea5u h\u00ecnh kh\u1ed1i","Hide summary":"\u1ea8n t\u00f3m t\u1eaft","Edit summary":"S\u1eeda t\u00f3m t\u1eaft","Don\u0027t display post information":"Hi\u1ec3n th\u1ecb tho\u1ea1i th\u00f4ng tin ch\u1eef","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"T\u00ean t\u1ec7p %filename kh\u00f4ng \u0111\u01b0\u1ee3c ph\u00e9p t\u1ea3i l\u00ean. Ch\u1ec9 c\u00f3 c\u00e1c t\u1ec7p v\u1edbi ph\u1ea7n m\u1edf r\u1ed9ng sau l\u00e0 \u0111\u01b0\u1ee3c ph\u00e9p: %extensions.","Autocomplete popup":"B\u1eadt l\u00ean t\u1ef1 ho\u00e0n t\u1ea5t","Searching for matches...":"T\u00ecm kh\u1edbp..."}} };;
(function ($) {

/**
 * A progressbar object. Initialized with the given id. Must be inserted into
 * the DOM afterwards through progressBar.element.
 *
 * method is the function which will perform the HTTP request to get the
 * progress bar state. Either "GET" or "POST".
 *
 * e.g. pb = new progressBar('myProgressBar');
 *      some_element.appendChild(pb.element);
 */
Drupal.progressBar = function (id, updateCallback, method, errorCallback) {
  var pb = this;
  this.id = id;
  this.method = method || 'GET';
  this.updateCallback = updateCallback;
  this.errorCallback = errorCallback;

  // The WAI-ARIA setting aria-live="polite" will announce changes after users
  // have completed their current activity and not interrupt the screen reader.
  this.element = $('<div class="progress" aria-live="polite"></div>').attr('id', id);
  this.element.html('<div class="bar"><div class="filled"></div></div>' +
                    '<div class="percentage"></div>' +
                    '<div class="message">&nbsp;</div>');
};

/**
 * Set the percentage and status message for the progressbar.
 */
Drupal.progressBar.prototype.setProgress = function (percentage, message) {
  if (percentage >= 0 && percentage <= 100) {
    $('div.filled', this.element).css('width', percentage + '%');
    $('div.percentage', this.element).html(percentage + '%');
  }
  $('div.message', this.element).html(message);
  if (this.updateCallback) {
    this.updateCallback(percentage, message, this);
  }
};

/**
 * Start monitoring progress via Ajax.
 */
Drupal.progressBar.prototype.startMonitoring = function (uri, delay) {
  this.delay = delay;
  this.uri = uri;
  this.sendPing();
};

/**
 * Stop monitoring progress via Ajax.
 */
Drupal.progressBar.prototype.stopMonitoring = function () {
  clearTimeout(this.timer);
  // This allows monitoring to be stopped from within the callback.
  this.uri = null;
};

/**
 * Request progress data from server.
 */
Drupal.progressBar.prototype.sendPing = function () {
  if (this.timer) {
    clearTimeout(this.timer);
  }
  if (this.uri) {
    var pb = this;
    // When doing a post request, you need non-null data. Otherwise a
    // HTTP 411 or HTTP 406 (with Apache mod_security) error may result.
    $.ajax({
      type: this.method,
      url: this.uri,
      data: '',
      dataType: 'json',
      success: function (progress) {
        // Display errors.
        if (progress.status == 0) {
          pb.displayError(progress.data);
          return;
        }
        // Update display.
        pb.setProgress(progress.percentage, progress.message);
        // Schedule next timer.
        pb.timer = setTimeout(function () { pb.sendPing(); }, pb.delay);
      },
      error: function (xmlhttp) {
        pb.displayError(Drupal.ajaxError(xmlhttp, pb.uri));
      }
    });
  }
};

/**
 * Display errors on the page.
 */
Drupal.progressBar.prototype.displayError = function (string) {
  var error = $('<div class="messages error"></div>').html(string);
  $(this.element).before(error).hide();

  if (this.errorCallback) {
    this.errorCallback(this);
  }
};

})(jQuery);
;
/**
 * @file
 * Provides JavaScript additions to the managed file field type.
 *
 * This file provides progress bar support (if available), popup windows for
 * file previews, and disabling of other file fields during Ajax uploads (which
 * prevents separate file fields from accidentally uploading files).
 */

(function ($) {

/**
 * Attach behaviors to managed file element upload fields.
 */
Drupal.behaviors.fileValidateAutoAttach = {
  attach: function (context, settings) {
    if (settings.file && settings.file.elements) {
      $.each(settings.file.elements, function(selector) {
        var extensions = settings.file.elements[selector];
        $(selector, context).bind('change', {extensions: extensions}, Drupal.file.validateExtension);
      });
    }
  },
  detach: function (context, settings) {
    if (settings.file && settings.file.elements) {
      $.each(settings.file.elements, function(selector) {
        $(selector, context).unbind('change', Drupal.file.validateExtension);
      });
    }
  }
};

/**
 * Attach behaviors to the file upload and remove buttons.
 */
Drupal.behaviors.fileButtons = {
  attach: function (context) {
    $('input.form-submit', context).bind('mousedown', Drupal.file.disableFields);
    $('div.form-managed-file input.form-submit', context).bind('mousedown', Drupal.file.progressBar);
  },
  detach: function (context) {
    $('input.form-submit', context).unbind('mousedown', Drupal.file.disableFields);
    $('div.form-managed-file input.form-submit', context).unbind('mousedown', Drupal.file.progressBar);
  }
};

/**
 * Attach behaviors to links within managed file elements.
 */
Drupal.behaviors.filePreviewLinks = {
  attach: function (context) {
    $('div.form-managed-file .file a, .file-widget .file a', context).bind('click',Drupal.file.openInNewWindow);
  },
  detach: function (context){
    $('div.form-managed-file .file a, .file-widget .file a', context).unbind('click', Drupal.file.openInNewWindow);
  }
};

/**
 * File upload utility functions.
 */
Drupal.file = Drupal.file || {
  /**
   * Client-side file input validation of file extensions.
   */
  validateExtension: function (event) {
    // Remove any previous errors.
    $('.file-upload-js-error').remove();

    // Add client side validation for the input[type=file].
    var extensionPattern = event.data.extensions.replace(/,\s*/g, '|');
    if (extensionPattern.length > 1 && this.value.length > 0) {
      var acceptableMatch = new RegExp('\\.(' + extensionPattern + ')$', 'gi');
      if (!acceptableMatch.test(this.value)) {
        var error = Drupal.t("The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.", {
          // According to the specifications of HTML5, a file upload control
          // should not reveal the real local path to the file that a user
          // has selected. Some web browsers implement this restriction by
          // replacing the local path with "C:\fakepath\", which can cause
          // confusion by leaving the user thinking perhaps Drupal could not
          // find the file because it messed up the file path. To avoid this
          // confusion, therefore, we strip out the bogus fakepath string.
          '%filename': this.value.replace('C:\\fakepath\\', ''),
          '%extensions': extensionPattern.replace(/\|/g, ', ')
        });
        $(this).closest('div.form-managed-file').prepend('<div class="messages error file-upload-js-error" aria-live="polite">' + error + '</div>');
        this.value = '';
        return false;
      }
    }
  },
  /**
   * Prevent file uploads when using buttons not intended to upload.
   */
  disableFields: function (event){
    var clickedButton = this;

    // Only disable upload fields for Ajax buttons.
    if (!$(clickedButton).hasClass('ajax-processed')) {
      return;
    }

    // Check if we're working with an "Upload" button.
    var $enabledFields = [];
    if ($(this).closest('div.form-managed-file').length > 0) {
      $enabledFields = $(this).closest('div.form-managed-file').find('input.form-file');
    }

    // Temporarily disable upload fields other than the one we're currently
    // working with. Filter out fields that are already disabled so that they
    // do not get enabled when we re-enable these fields at the end of behavior
    // processing. Re-enable in a setTimeout set to a relatively short amount
    // of time (1 second). All the other mousedown handlers (like Drupal's Ajax
    // behaviors) are excuted before any timeout functions are called, so we
    // don't have to worry about the fields being re-enabled too soon.
    // @todo If the previous sentence is true, why not set the timeout to 0?
    var $fieldsToTemporarilyDisable = $('div.form-managed-file input.form-file').not($enabledFields).not(':disabled');
    $fieldsToTemporarilyDisable.attr('disabled', 'disabled');
    setTimeout(function (){
      $fieldsToTemporarilyDisable.attr('disabled', false);
    }, 1000);
  },
  /**
   * Add progress bar support if possible.
   */
  progressBar: function (event) {
    var clickedButton = this;
    var $progressId = $(clickedButton).closest('div.form-managed-file').find('input.file-progress');
    if ($progressId.length) {
      var originalName = $progressId.attr('name');

      // Replace the name with the required identifier.
      $progressId.attr('name', originalName.match(/APC_UPLOAD_PROGRESS|UPLOAD_IDENTIFIER/)[0]);

      // Restore the original name after the upload begins.
      setTimeout(function () {
        $progressId.attr('name', originalName);
      }, 1000);
    }
    // Show the progress bar if the upload takes longer than half a second.
    setTimeout(function () {
      $(clickedButton).closest('div.form-managed-file').find('div.ajax-progress-bar').slideDown();
    }, 500);
  },
  /**
   * Open links to files within forms in a new window.
   */
  openInNewWindow: function (event) {
    $(this).attr('target', '_blank');
    window.open(this.href, 'filePreview', 'toolbar=0,scrollbars=1,location=1,statusbar=1,menubar=0,resizable=1,width=500,height=550');
    return false;
  }
};

})(jQuery);
;
window.CKEDITOR_BASEPATH = '/sites/all/libraries/ckeditor/';;
